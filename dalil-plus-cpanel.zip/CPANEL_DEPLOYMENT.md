# دليل رفع دليل بلس على cPanel
# Dalil Plus — cPanel Deployment Guide

---

## المحتويات / Contents

```
dist/
├── frontend/          ← ملفات الواجهة الأمامية (React)  /  Frontend static files
├── laravel-api/       ← الـ API الخلفي بـ PHP/Laravel   /  PHP Laravel backend (recommended for cPanel)
├── nodejs-api/        ← الـ API الخلفي بـ Node.js        /  Node.js Express backend (alternative)
└── CPANEL_DEPLOYMENT.md
```

---

## الطريقة الموصى بها: PHP Laravel + MySQL
## Recommended: PHP Laravel + MySQL

هذه الطريقة تعمل على أي استضافة cPanel بدون أي إعدادات إضافية.
This works on any standard cPanel hosting without extra configuration.

### المتطلبات / Requirements
- PHP 8.2+
- MySQL 5.7+ أو MariaDB 10.3+
- Composer (عبر SSH أو Terminal في cPanel)
- mod_rewrite مفعّل

---

## الخطوة 1: رفع الـ API (Laravel)
## Step 1: Upload the API (Laravel)

### 1.1 ضغط الملفات / Zip the files
على جهازك، اضغط مجلد `dist/laravel-api/`:
On your computer, zip the `dist/laravel-api/` folder:
```bash
cd dist
zip -r dalil-api.zip laravel-api/ --exclude "*.git*"
```

### 1.2 رفع وفك الضغط / Upload and extract
1. افتح **cPanel → File Manager**
2. اذهب إلى مجلد خارج `public_html` (مثلاً `/home/youraccount/`)
3. ارفع `dalil-api.zip` واضغط **Extract**
4. سيكون المجلد الآن: `/home/youraccount/laravel-api/`

### 1.3 إنشاء قاعدة البيانات / Create database
1. **cPanel → MySQL Databases**
2. أنشئ قاعدة بيانات جديدة (مثلاً: `youraccount_dalil`)
3. أنشئ مستخدم جديد وأعطه كل الصلاحيات على القاعدة

### 1.4 إعداد ملف .env / Configure .env
افتح **File Manager** واذهب لـ `/home/youraccount/laravel-api/`
انسخ `.env.example` إلى `.env` وعدّل هذه القيم:
```
APP_NAME="دليل بلس"
APP_URL=https://yourdomain.com
APP_ENV=production
APP_DEBUG=false

DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=youraccount_dalil
DB_USERNAME=youraccount_daliluser
DB_PASSWORD=YourStrongPassword
```

### 1.5 تنفيذ الأوامر عبر SSH أو Terminal
```bash
cd /home/youraccount/laravel-api

# تثبيت المكتبات
composer install --optimize-autoloader --no-dev

# توليد مفتاح التطبيق
php artisan key:generate

# تنفيذ المايغريشن وإدخال البيانات
php artisan migrate --force
php artisan db:seed --force

# ربط مجلد التخزين
php artisan storage:link

# تحسين الأداء
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

### 1.6 توجيه الـ API لمجلد public / Point API domain to public
**Option A — Subdomain (موصى به):**
1. **cPanel → Subdomains** → أنشئ `api.yourdomain.com`
2. اضبط Document Root على: `/home/youraccount/laravel-api/public`

**Option B — نفس الدومين بمسار /api:**
أضف هذا في `public_html/.htaccess`:
```apache
RewriteEngine On
RewriteRule ^api-backend/(.*)$ /home/youraccount/laravel-api/public/$1 [L]
```

---

## الخطوة 2: رفع الواجهة الأمامية (React)
## Step 2: Upload the Frontend (React)

### 2.1 إذا كان الـ API على subdomain (api.yourdomain.com)
يجب إعادة بناء الواجهة مع رابط الـ API. أضف ملف `.env.production` في `artifacts/marketplace/`:
```
VITE_API_BASE_URL=https://api.yourdomain.com
```
ثم أعد البناء:
```bash
pnpm --filter @workspace/marketplace run build
```
ثم ارفع محتوى `artifacts/marketplace/dist/public/`

### 2.2 إذا كان الـ API على نفس الدومين
ارفع ملفات `dist/frontend/` مباشرة إلى `public_html/`:
- `index.html`
- `assets/` (المجلد كاملاً)
- `favicon.svg`
- `images/`
- `.htaccess`

### 2.3 رفع الملفات / Upload files
1. **cPanel → File Manager → public_html**
2. ارفع ملفات `dist/frontend/` كلها
3. تأكد أن `.htaccess` موجود (قد يكون مخفياً — فعّل "Show Hidden Files")

---

## الخطوة 3: التحقق / Verification

افتح المتصفح على `https://yourdomain.com` — يجب أن تظهر الصفحة الرئيسية.
افتح `https://api.yourdomain.com/api/health` — يجب أن يرجع `{"status":"ok"}`.

بيانات الدخول الافتراضية للأدمن:
- Email: `admin@daleel.sa`
- Password: `Admin@123456`

---

## بديل: Node.js API (إذا كان cPanel يدعم Node.js)
## Alternative: Node.js API (if cPanel supports Node.js)

### المتطلبات
- Node.js 18+ في cPanel
- PostgreSQL (أو استخدم PlanetScale/Neon.tech كـ external DB)

### الخطوات
1. **cPanel → Setup Node.js App** → أنشئ تطبيق جديد
2. اضبط:
   - Node.js version: 18+
   - Application mode: Production
   - Application root: `/home/youraccount/dalil-node/`
   - Application startup file: `index.mjs`
3. ارفع ملفات `dist/nodejs-api/` إلى `/home/youraccount/dalil-node/`
4. ارفع ملفات `dist/frontend/` إلى نفس المجلد في `public/`
5. أضف متغيرات البيئة:
   ```
   DATABASE_URL=postgresql://user:pass@host:5432/dbname
   NODE_ENV=production
   PORT=3000
   ```
6. شغّل: `npm install && node index.mjs`

---

## إعداد CORS / CORS Setup

إذا كان الـ API على subdomain، أضف هذا في Laravel `config/cors.php`:
```php
'allowed_origins' => ['https://yourdomain.com'],
'supports_credentials' => true,
```

---

## الدعم الفني / Support

- بيانات Admin: `admin@daleel.sa` / `Admin@123456`
- بيانات Moderator: `moderator@daleel.sa` / `Mod@123456`
